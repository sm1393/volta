import websocket
import mouse
import time
import json
from signal import signal, SIGINT
import sys
import os

URL="ws://"+"192.168.216.124"+":7000"

# def signal_handler(signal_received, frame):
#     print("Exiting Flask Server")
#     rospy.signal_shutdown("Keyboard Interrupt") 
#     sys.exit()

def signal_handler(signal_received, frame):
    print("Exiting Glove Client")
    sys.exit()

signal(SIGINT,signal_handler)

class mouse_client:
    def __init__(self):
        self.url = URL
        self.ws_obj=self.establish_connection()
    
    def establish_connection(self):
        print("Establishing connection")
        conn=False
        while conn is False:
            try:
                #obj=websocket.create_connection(self.url,timeout=1)
                obj=websocket.create_connection(self.url)
                print("Connection Established")
                conn=True
            except:
                print("Trying to establish connection to gloves")
                time.sleep(1)
        return obj

    def get_controller_data(self):
        try:
            self.ws_obj.send("Ack")
            data=json.loads(self.ws_obj.recv())
            return data
        except Exception as e:
            print(e)
            self.ws_obj=self.establish_connection()

    def move_mouse(self):
        while True:
            try:
                data=self.get_controller_data()
                if data!=None:
                    if data['trigger']==1.0:
                        mouse.click(button='left')
                        time.sleep(0.3)

                    x_val=data['trackpad_x']
                    y_val=data['trackpad_y']
                    print(x_val,y_val)
                    mouse.move(x_val*10,-y_val*10,False,0.01)

            except Exception as e:
                print("Error occured: ",e)


if __name__=="__main__":
    mouse_obj=mouse_client()
    mouse_obj.move_mouse()

